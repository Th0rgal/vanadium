import urllib.request,json,datetime
rows=[]
for device,port in [('nanosp',5501),('nanox',5601)]:
 url=f'http://127.0.0.1:{port}/events?currentscreenonly=true'
 try:
  with urllib.request.urlopen(url,timeout=5) as response:
   body=response.read();rows.append({'device':device,'url':url,'http_status':response.status,'json':json.loads(body)})
 except Exception as error:rows.append({'device':device,'url':url,'error':repr(error)})
print(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'GET only; no buttons, navigation, APDU or configuration mutation','screens':rows},indent=2))
