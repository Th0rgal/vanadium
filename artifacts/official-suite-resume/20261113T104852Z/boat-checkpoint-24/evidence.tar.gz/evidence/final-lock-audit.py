from pathlib import Path
import subprocess,hashlib,json,datetime
r=Path('/var/lib/orb-node/work/official-suite-resume');rows=[]
for name in ['vanadium','app-bitcoin','app-testnet','app-mainnet','app-slow-diagnostic','app-fixture-fix','lean-ledger-bitcoin','turbo-lean','ledger-secure-sdk','ledger-app-builder','native-ctest/_deps/speculos-src']:
 repo=r/name
 for path in subprocess.check_output(['git','ls-files','--','*Cargo.lock'],cwd=repo,text=True).splitlines():
  original=subprocess.check_output(['git','show','HEAD:'+path],cwd=repo);actual=(repo/path).read_bytes()
  rows.append({'repo':name,'path':path,'unchanged':original==actual,'sha256':hashlib.sha256(actual).hexdigest()})
new=[]
for path in ['vanadium/apps/bitcoin/app/Cargo.lock','vanadium/apps/bitcoin/common/Cargo.lock','root-lock-overlay/Cargo.lock','evidence/core-setup-permanent-error.patch','evidence/nested-lockfiles.patch','evidence/root-common-overlay.patch','lean-ledger-bitcoin/ffi/vanadium/build/host/liblean_ledger_bitcoin.a']:
 p=r/path;new.append({'path':path,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size})
print(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tracked_locks':rows,'private_artifacts':new},indent=2));assert all(v['unchanged'] for v in rows)
