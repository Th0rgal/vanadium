from pathlib import Path
import tarfile,json,datetime,hashlib
r=Path('/var/lib/orb-node/work/official-suite-resume');p=r/'evidence.tar.gz';rows=[];bad=[]
with tarfile.open(p) as t:
 for m in t.getmembers():
  if not m.isfile():continue
  data=t.extractfile(m).read();rows.append({'name':m.name,'size':m.size})
  if data.startswith((b'\x7fELF',b'!<arch>')) or b'\x00' in data:bad.append(m.name)
 required=['evidence/native-ctest/Testing/Temporary/LastTest.log','evidence/native-ctest/CMakeCache.txt','evidence/REPORT.md','evidence/counts.json','evidence/core-setup-permanent-error.patch','evidence/nested-lockfiles.patch','evidence/root-common-overlay.patch']
 names={v['name'] for v in rows};missing=[v for v in required if v not in names]
print(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'members':len(rows),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'binary_suspects':bad,'missing_required':missing},indent=2))
assert not bad and not missing and p.stat().st_size<20*1024*1024
