# BLOCKED — final official-suite evidence, 2026-11-13

No overall PASS. Full application suites completed with real failures; root common could not start under its immutable existing lock. This report supersedes distinctly named historical reports. Raw per-run commands, stdout/stderr, JUnit, exit records and counts.json are authoritative.

## Completed official results

| Suite | Pass | Fail | Skip | Deselected | Exit |
|---|---:|---:|---:|---:|---:|
| Native CTest (target level only) |31|0|0|0|0|
| Bitcoin Rust app, locked |90|0|0|0|0|
| Bitcoin Rust common, locked |85|0|0|0|0|
| Mainnet nanosp, slow2 |2|0|0|0|0|
| Mainnet nanox, slow2 |2|0|0|0|0|
| Full Ragger testnet nanosp, slow2 |279|2|1|0|1|
| Full Ragger testnet nanox, slow2 |279|2|1|0|1|
| Root common exact locked canary |null|null|null|null|101|

CTest enumerated31 targets: upstream30 plus1added; raw enumeration and delta retained. Full CMocka output: native-ctest/Testing/Temporary/LastTest.log (SHA2564995b4cb24efbd8329ea7f733cbcabb1a6f538e0ca5b9da36fcdb8c39bf2aed5). CMakeCache.txt included. CTest was not repeated. Common Rust85 is81unit +4integration; doctests0. Mainnet uses upstream legacy Speculos fixtures and distinct authentic mainnet builds.

Both full testnet runs collected282, executed the full directory on explicit isolated ports with unchanged upstream skip rules and slow=2, timeout300. The single upstream skip per device is test_get_extended_pubkey_non_standard_reject_early, instructions.py:105; original reason is Skipped. Exact cases/reasons in skip-reasons.json. No added exclusions, no deselection, no golden regeneration.

## Failures and safe next steps

The512-input case times out at300 seconds in host PSBT generation: txmaker.createPsbt -> key.taproot_tweak_pubkey -> point_mul -> point_add modular exponentiation. Separate exact-node diagnostics on BOTH devices, timeout1800, also fail (0passed/1failed each) after reaching client.sign_psbt and waiting in Ragger has_data_available/select.select for the signing APDU response. These are genuine timeout failures, not passing subsets; neither proves a signature/assertion bug. Safe next step: instrument authentic Speculos/APDU progress and allow a measured longer execution window; do not reduce the input count or weaken assertions.

The full runs also fail test_sign_psbt_musig2_evicts_oldest_session during nonce generation with requests.ConnectionError/connection refused on the isolated Speculos API. No assertion failure establishes a Bitcoin bug. Earlier interrupted full runs show this node passing, but do not certify their incomplete suites. A separately logged exact-node nanox diagnostic PASSED1/1 in69.85 seconds using the same authentic binary on API5401, timeout300. This narrows an intermittent/full-run connection failure; it does not override either failed full suite. Safe next step: retain emulator process exit/stderr and reproduce serially before changing code. No backend/assertion/source patch was made.

Root common canary command cargo +stable test --locked -p common vm::tests::test_vec_memory_new -- --exact exits101 before compilation: upstream manifest/lock inconsistency (cargo-vnd/rhai_codegen edge). Full root-common suite is NOT RUN; counts null. This is a LOCAL SOURCE/LOCK CONSISTENCY BLOCKER, not an external missing SDK or Bitcoin behavior bug. Parent must reconcile the existing source/lock pair or demonstrate a matching toolchain. No silent lock update or unlocked test. Root lock unchanged SHA256139326fa0b3bd5d75ba9447549493fd135330d1f2bf51a0d9c95ee50a04e7546.

## Authentic provisioning and provenance

Sources: vanadium045439a8c1a984b67f13b913df7c75002ef732a7; app-bitcoinafe126fea70c8c7d6091948bb8a8ae529ea89a60; Lean baselinef68864d1f2af8fd9f2ca26acddb5f0abd3e80bcb (CandidateA never substituted). SDKv27.1.7 SHA9ea0fae9b40bb91e7c4f94bb0e9b8cf22df36306; builder98693c3b63446779677d35bd7ed7c5923949ab01; CTest Speculosv0.25.13 ad72692eacd8d961a42c95d5c4fda9d3573c2427. Python Speculos0.27.4/Ragger1.47.4, Core32.1 verified by upstream setup script, CMocka1.1.7, LLVM21.1.8 and authentic ARM tools privately provisioned. Extracted libtoolize data paths were relocated only inside the private authentic tool; requirements/assertions untouched.

Authentic public turbo-lean feat/freestanding-flat-ptr-loops8c3503fa0df74fafcd7a3b91e4319606985b7198 emits baseline host FFI successfully (45exports,0undefined,296-byte max host stack frame). Earlier missing-emitter errors are superseded. New private nested app/common Cargo.lock files generated from unchanged manifests are archived, hashed, and returned as nested-lockfiles.patch for parent signing; pristine-HEAD patch application check passed. Existing tracked locks remain unchanged.

Fresh full source/SDK/Speculos/compiler status, diffs, exact SHAs, versions and lock hashes are in final-provenance-frozen.* (with earlier final-provenance-completed-suites.* retained). All tracked diffs empty. Untracked private test-node/build outputs are explicitly shown. Native mainnet/testnet builds remain distinct, DEBUG0. No app/spec/test weakening, stubs, credentials, privileges, Docker bypass, commits/push, merge/deploy, other models or subagents. Heavy work only this VM, build jobs<=4, Rust1; TTL12:22Z unchanged.

Historical unsuccessful provisioning attempts and interrupted sessions are retained, not counted as passes. Four prior test/diagnostic processes disappeared without exit records before this continuation; cause not established. Their counts/exits remain null. Later explicit interruptions have exit2 and partial terminal counts; suite_complete=false. Initial preparation and some read-only interactive probes were not individually wrapped in archived run records; no retrospective output was invented. Build/test records and runner scripts are included. Logs/text/locks/patch only, no binaries or caches.

## Per-run results (null means no completion record)

```json
{
  "ctest_full": {
    "exit": 0,
    "pass": 31,
    "fail": 0,
    "skip": 0,
    "errors": 0,
    "deselected": 0,
    "reported_cases": 31,
    "execution_complete": true,
    "log": "ctest-full"
  },
  "mainnet_nanosp": {
    "exit": 0,
    "pass": 2,
    "fail": 0,
    "skip": 0,
    "errors": 0,
    "deselected": 0,
    "reported_cases": 2,
    "terminal_summary": "============================== 2 passed in 2.41s ===============================",
    "execution_complete": true,
    "suite_complete": true,
    "log": "mainnet-nanosp"
  },
  "mainnet_nanox": {
    "exit": 0,
    "pass": 2,
    "fail": 0,
    "skip": 0,
    "errors": 0,
    "deselected": 0,
    "reported_cases": 2,
    "terminal_summary": "============================== 2 passed in 2.36s ===============================",
    "execution_complete": true,
    "suite_complete": true,
    "log": "mainnet-nanox2"
  },
  "testnet_nanosp": {
    "exit": 1,
    "pass": 279,
    "fail": 2,
    "skip": 1,
    "errors": 0,
    "deselected": 0,
    "reported_cases": 282,
    "terminal_summary": "===== 2 failed, 279 passed, 1 skipped, 273 warnings in 1699.90s (0:28:19) ======",
    "execution_complete": true,
    "suite_complete": true,
    "log": "ragger-tests-nanosp-final2"
  },
  "testnet_nanox": {
    "exit": 1,
    "pass": 279,
    "fail": 2,
    "skip": 1,
    "errors": 0,
    "deselected": 0,
    "reported_cases": 282,
    "terminal_summary": "===== 2 failed, 279 passed, 1 skipped, 273 warnings in 1698.33s (0:28:18) ======",
    "execution_complete": true,
    "suite_complete": true,
    "log": "ragger-tests-nanox-final"
  },
  "initial_testnet_nanosp": {
    "status": "NO_COMPLETION_RECORD",
    "pass": null,
    "fail": null,
    "skip": null,
    "errors": null,
    "deselected": null,
    "exit": null,
    "log": "ragger-tests-nanosp3"
  },
  "initial_testnet_nanox": {
    "status": "NO_COMPLETION_RECORD",
    "pass": null,
    "fail": null,
    "skip": null,
    "errors": null,
    "deselected": null,
    "exit": null,
    "log": "ragger-tests-nanox"
  },
  "bitcoin_rust_app": {
    "exit": 0,
    "pass": 90,
    "fail": 0,
    "skip": 0,
    "errors": 0,
    "deselected": 0,
    "rust_result_groups": [
      [
        90,
        0,
        0,
        0,
        0
      ]
    ],
    "execution_complete": true,
    "log": "bitcoin-app-with-ffi"
  },
  "bitcoin_rust_common": {
    "exit": 0,
    "pass": 85,
    "fail": 0,
    "skip": 0,
    "errors": 0,
    "deselected": 0,
    "rust_result_groups": [
      [
        81,
        0,
        0,
        0,
        0
      ],
      [
        1,
        0,
        0,
        0,
        0
      ],
      [
        2,
        0,
        0,
        0,
        0
      ],
      [
        1,
        0,
        0,
        0,
        0
      ],
      [
        0,
        0,
        0,
        0,
        0
      ]
    ],
    "execution_complete": true,
    "log": "bitcoin-common-with-ffi"
  },
  "root_common_canary": {
    "exit": 101,
    "pass": null,
    "fail": null,
    "skip": null,
    "errors": null,
    "deselected": null,
    "execution_complete": false,
    "log": "common-canary"
  },
  "testnet_nanosp_long": {
    "exit": 2,
    "pass": 1,
    "fail": 0,
    "skip": 0,
    "errors": 0,
    "deselected": 0,
    "reported_cases": 1,
    "terminal_summary": "=================== 1 passed, 3 warnings in 60.30s (0:01:00) ===================",
    "execution_complete": false,
    "suite_complete": false,
    "log": "ragger-tests-nanosp-long"
  },
  "testnet_nanox_long": {
    "exit": 2,
    "pass": 4,
    "fail": 0,
    "skip": 0,
    "errors": 0,
    "deselected": 0,
    "reported_cases": 5,
    "terminal_summary": "======================== 4 passed, 7 warnings in 59.21s ========================",
    "execution_complete": false,
    "suite_complete": false,
    "log": "ragger-tests-nanox-long"
  },
  "diagnostic_512_nanosp": {
    "status": "NO_COMPLETION_RECORD",
    "pass": null,
    "fail": null,
    "skip": null,
    "errors": null,
    "deselected": null,
    "exit": null,
    "log": "diagnostic-512-nanosp"
  },
  "diagnostic_512_nanox": {
    "status": "NO_COMPLETION_RECORD",
    "pass": null,
    "fail": null,
    "skip": null,
    "errors": null,
    "deselected": null,
    "exit": null,
    "log": "diagnostic-512-nanox"
  },
  "testnet_nanosp_final": {
    "exit": 1,
    "pass": 279,
    "fail": 2,
    "skip": 1,
    "errors": 0,
    "deselected": 0,
    "reported_cases": 282,
    "terminal_summary": "===== 2 failed, 279 passed, 1 skipped, 273 warnings in 1699.90s (0:28:19) ======",
    "execution_complete": true,
    "suite_complete": true,
    "log": "ragger-tests-nanosp-final2"
  },
  "testnet_nanox_final": {
    "exit": 1,
    "pass": 279,
    "fail": 2,
    "skip": 1,
    "errors": 0,
    "deselected": 0,
    "reported_cases": 282,
    "terminal_summary": "===== 2 failed, 279 passed, 1 skipped, 273 warnings in 1698.33s (0:28:18) ======",
    "execution_complete": true,
    "suite_complete": true,
    "log": "ragger-tests-nanox-final"
  },
  "diagnostic_512_nanosp_retry": {
    "exit": 1,
    "pass": 0,
    "fail": 1,
    "skip": 0,
    "errors": 0,
    "deselected": 0,
    "reported_cases": 1,
    "terminal_summary": "================== 1 failed, 2 warnings in 1801.20s (0:30:01) ==================",
    "execution_complete": true,
    "suite_complete": false,
    "log": "diagnostic-512-nanosp-retry"
  },
  "diagnostic_512_nanox_retry": {
    "exit": 1,
    "pass": 0,
    "fail": 1,
    "skip": 0,
    "errors": 0,
    "deselected": 0,
    "reported_cases": 1,
    "terminal_summary": "================== 1 failed, 2 warnings in 1801.02s (0:30:01) ==================",
    "execution_complete": true,
    "suite_complete": false,
    "log": "diagnostic-512-nanox-retry"
  },
  "diagnostic_eviction_nanox": {
    "exit": 0,
    "pass": 1,
    "fail": 0,
    "skip": 0,
    "errors": 0,
    "deselected": 0,
    "reported_cases": 1,
    "terminal_summary": "=================== 1 passed, 2 warnings in 69.85s (0:01:09) ===================",
    "execution_complete": true,
    "suite_complete": false,
    "log": "diagnostic-eviction-nanox"
  }
}
```

## Configure attempts (per-run, not aggregated)

app-configure: exit 1; see exact argv and logs.

ctest-native-configure: exit 0; see exact argv and logs.

ctest-llvm21-configure: exit 0; see exact argv and logs.

