from pathlib import Path
import os,json,datetime
r=Path('/var/lib/orb-node/work/official-suite-resume');e=r/'evidence';hz=os.sysconf('SC_CLK_TCK');uptime=float(Path('/proc/uptime').read_text().split()[0]);rows=[];chosen=set();stats={}
for name in ['ragger-tests-nanosp-1800-full-retry3','ragger-tests-nanox-1800-full-retry3']:
 for suffix,key in [('.launch.json','runner_pid'),('.active.json','child_pid')]:
  p=e/(name+suffix)
  if p.exists():chosen.add(json.loads(p.read_text())[key])
for dev in ['nanosp','nanox']:
 p=r/f'core-1800-fresh3-{dev}/regtest/bitcoind.pid'
 if p.exists():chosen.add(int(p.read_text()))
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  raw=(p/'stat').read_text();v=raw[raw.rfind(')')+2:].split();stats[int(p.name)]=v
 except (FileNotFoundError,ProcessLookupError,PermissionError):pass
while True:
 found={pid for pid,v in stats.items() if int(v[1]) in chosen}
 if found.issubset(chosen):break
 chosen.update(found)
for pid in sorted(chosen):
 if pid not in stats:continue
 try:
  p=Path('/proc')/str(pid);v=stats[pid];args=[x.decode(errors='replace') for x in (p/'cmdline').read_bytes().split(b'\0') if x];status=(p/'status').read_text().splitlines()
  rows.append({'pid':pid,'ppid':int(v[1]),'state':v[0],'elapsed_seconds':round(uptime-int(v[19])/hz,3),'user_cpu_seconds':int(v[11])/hz,'system_cpu_seconds':int(v[12])/hz,'rss':next((x for x in status if x.startswith('VmRSS:')),None),'argv':args})
 except (FileNotFoundError,ProcessLookupError,PermissionError):pass
print(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'active_deadline':json.loads((e/'monitor-retry3-active.json').read_text())['active_deadline_utc'],'processes':rows},indent=2))
