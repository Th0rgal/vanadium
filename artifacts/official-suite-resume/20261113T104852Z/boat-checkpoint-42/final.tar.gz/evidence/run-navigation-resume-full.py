"""Execute prepared official selections after parent confirms the owned Boat expiry.
No lease operations or test signals. Keep executor turn alive until both finish.
"""
import argparse,datetime,json,os,pathlib,subprocess,threading,time
R=pathlib.Path('/var/lib/orb-node/work/official-suite-resume');E=R/'evidence'
p=argparse.ArgumentParser();p.add_argument('--confirmed-expiry-epoch',required=True,type=int);a=p.parse_args()
assert a.confirmed_expiry_epoch>time.time(),'Need current parent-confirmed lease; no automatic extension'
assert json.loads((E/'diagnostic-512-nanox-navigation-fix-verified.json').read_text())['exit']==0
jobs=json.loads((E/'navigation-resume-full-frozen-commands-1721.json').read_text())['commands']
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def atomic(path,data):
 tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(data,indent=2));tmp.replace(path)
# Do not duplicate runs or reuse Core databases, even after an interrupted executor.
for job in jobs:
 assert not (E/(job['name']+'.active.json')).exists()
 assert not pathlib.Path(job['env']['BITCOIN_DIRNAME']).exists()
results={};lock=threading.Lock()
def run(job):
 name=job['name'];env=os.environ.copy();env.update(job['env'])
 rec={'cwd':job['cwd'],'argv':job['argv'],'env':job['env'],'started_utc':now(),'confirmed_expiry_epoch':a.confirmed_expiry_epoch,'advisory_deadline_utc':'2026-11-13T18:20:00Z','deadline_action':'record only; never signal tests','signals_sent':[],'classification':'FULL_SELECTION_RESUME_HOST_RUNTIME_CANDIDATE_NOT_BASELINE','frozen_plugin':json.loads((E/'navigation-resume-full-frozen-commands-1721.json').read_text())['frozen_plugin']}
 with (E/(name+'.stdout')).open('wb') as out,(E/(name+'.stderr')).open('wb') as err:
  child=subprocess.Popen(job['argv'],cwd=job['cwd'],env=env,stdout=out,stderr=err);rec['pid']=child.pid;atomic(E/(name+'.active.json'),rec)
  code=child.wait()
 rec.update(exit=code,ended_utc=now());atomic(E/(name+'.json'),rec)
 with lock:results[name]=rec
threads=[threading.Thread(target=run,args=(job,)) for job in jobs]
for thread in threads:thread.start()
while any(thread.is_alive() for thread in threads):
 atomic(E/'navigation-resume-full-runtime-status.json',{'utc':now(),'confirmed_expiry_epoch':a.confirmed_expiry_epoch,'advisory_deadline_utc':'2026-11-13T18:20:00Z','deadline_action':'record only; never signal tests','completed':list(results),'active':[j['name'] for j,t in zip(jobs,threads) if t.is_alive()]})
 time.sleep(10)
for thread in threads:thread.join()
atomic(E/'navigation-resume-full-runtime-status.json',{'utc':now(),'completed':list(results),'active':[],'signals_sent':[]})
print(json.dumps(results),flush=True)
