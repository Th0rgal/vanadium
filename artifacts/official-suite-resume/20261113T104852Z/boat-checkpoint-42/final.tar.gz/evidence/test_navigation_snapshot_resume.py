from pathlib import Path
from inspect import signature
from unittest.mock import Mock
import pytest
from ragger.navigator import Navigator, NavInsID
from ragger.error import ExceptionRAPDU

@pytest.mark.parametrize('method', ['navigate_until_text_and_compare', 'navigate_and_compare'])
def test_interrupted_wait_preserves_every_snapshot_and_click(method):
    nav=Navigator.__new__(Navigator)
    page=[0]; interrupted=[False]; compared=[]; clicks=[]
    backend=Mock(); nav._backend=backend
    def click():
        page[0]+=1; clicks.append(page[0])
    def wait(timeout):
        if page[0]==2 and not interrupted[0]:
            interrupted[0]=True
            raise ExceptionRAPDU(0xE000,b'next output proof')
    backend.wait_for_screen_change.side_effect=wait
    backend.compare_screen_with_text.side_effect=lambda text:page[0]==3
    nav._callbacks={NavInsID.WAIT:lambda *a:None,NavInsID.RIGHT_CLICK:click}
    nav._init_snaps_temp_dir=lambda *a:Path('actual')
    nav._check_snaps_dir_path=lambda *a:Path('reference')
    nav._get_snaps_dir_path=lambda *a:Path('actual')
    def compare(actual,reference,index):
        assert index==page[0],f'Expected snapshot {index}, actual review page {page[0]}'
        compared.append(index)
    nav._compare_snap=compare
    fn=getattr(nav,method);state={}
    kwargs={'resume_state':state} if 'resume_state' in signature(fn).parameters else {}
    args=(NavInsID.RIGHT_CLICK,[], 'Approve',Path('.'),'case') if method=='navigate_until_text_and_compare' else (Path('.'),'case',[NavInsID.RIGHT_CLICK]*3)
    with pytest.raises(ExceptionRAPDU):fn(*args,**kwargs)
    fn(*args,**kwargs)
    assert clicks==[1,2,3]
    assert compared==[0,1,2,3]
    assert backend.pause_ticker.call_count==2
    assert backend.resume_ticker.call_count==2
