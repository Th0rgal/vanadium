from pathlib import Path
import subprocess,json,datetime
root=Path('/var/lib/orb-node/work/official-suite-resume');e=root/'evidence'
unit='sandboxed-node-d9bf22a0d48ae513763d63ad6f0a2eba-job-f32ce04047734612b04033f2bd122b9c.scope'
commands=[['systemctl','--user','show',unit,'--property=Id,LoadState,ActiveState,SubState,Result,KillMode,OOMPolicy,MemoryMax,MemoryHigh,RuntimeMaxUSec,ActiveEnterTimestamp,InactiveEnterTimestamp,InvocationID'],['journalctl','--user','--unit='+unit,'--since=2026-11-13 12:55:00 UTC','--until=2026-11-13 13:03:00 UTC','--no-pager','--output=short-iso']]
rows=[]
for argv in commands:
 try:
  p=subprocess.run(argv,capture_output=True,text=True,timeout=20);rows.append({'argv':argv,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 except subprocess.TimeoutExpired as ex:rows.append({'argv':argv,'exit':None,'error':'read-only probe timed out20s','stdout':str(ex.stdout),'stderr':str(ex.stderr)})
old=Path('/sys/fs/cgroup/user.slice/user-996.slice/user@996.service/app.slice')/unit
cg={'path':str(old),'exists':old.exists(),'files':{}}
for name in ['memory.events','memory.events.local','memory.peak','memory.max','cgroup.events']:
 p=old/name
 if p.exists():cg['files'][name]=p.read_text()
print(json.dumps({'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old_scope':unit,'old_scope_current_cgroup':cg,'current_process_cgroup':Path('/proc/self/cgroup').read_text(),'commands':rows,'interpretation':'setsid detaches process session but does not move a process out of its executor-owned systemd cgroup. Historical snapshot places both pytest runners and monitor in one job scope. This explains a shared cleanup vulnerability; exact disappearance cause still requires a journal/termination receipt, not an OOM inference.'},indent=2))
