from pathlib import Path
import os,subprocess,json,datetime,hashlib
R=Path('/var/lib/orb-node/work/official-suite-resume');E=R/'evidence'
for n in ['nanosp','nanox']:
 assert (E/('ragger-navigation-resume-full-'+n+'.json')).exists(),'Full run must complete before mainnet'
for device,build in [('nanosp','nanos2'),('nanox','nanox')]:
 assert not (E/('mainnet-navigation-resume-runtime-'+device+'.active.json')).exists(),'Do not duplicate mainnet'
 name='mainnet-navigation-resume-runtime-'+device;env=os.environ.copy();env.update(PATH=f'{R}/venv/bin:{R}/prefix/usr/bin:/usr/local/bin:/usr/bin:/bin',PYTHONPATH=':'.join(str(R/p) for p in ['evidence','ragger-navigation-resume/src','app-navigation-resume','speculos-candidate-runtime']),BITCOIN_APP_BINARY=str(R/'app-mainnet/build'/build/'bin/app.elf'),PYTHONWARNINGS='ignore::DeprecationWarning',NAV_PROVENANCE_FILE=name+'-provenance.json',TMPDIR=str(R/'tmp'))
 argv=[str(R/'venv/bin/python'),'-m','pytest','-p','navigation_resume_mainnet_provenance_20261113_1722','.','--headless','--model',device,'--enable_slow_tests=2','--timeout=300','-ra','-v','--junitxml='+str(E/(name+'.xml'))]
 d={'cwd':str(R/'app-navigation-resume/tests_mainnet'),'argv':argv,'env':{k:env[k] for k in ['PATH','PYTHONPATH','BITCOIN_APP_BINARY','PYTHONWARNINGS','NAV_PROVENANCE_FILE','TMPDIR']},'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'confirmed_expiry_epoch':1794594147,'advisory_deadline_utc':'2026-11-13T18:20:00Z','deadline_action':'recordonly; neversignaltests','baseline_mainnet_ELF_sha256':hashlib.sha256(Path(env['BITCOIN_APP_BINARY']).read_bytes()).hexdigest(),'isolation':'sequentialmainnet default5000 AFTER newest fulltestnet7601/7701 terminal; no overlap','frozen_plugin':{'path':str(E/'navigation_resume_mainnet_provenance_20261113_1722.py'),'sha256':hashlib.sha256((E/'navigation_resume_mainnet_provenance_20261113_1722.py').read_bytes()).hexdigest()}}
 with (E/(name+'.stdout')).open('wb') as out,(E/(name+'.stderr')).open('wb') as err:
  c=subprocess.Popen(argv,cwd=d['cwd'],env=env,stdout=out,stderr=err);d['pid']=c.pid;(E/(name+'.active.json')).write_text(json.dumps(d,indent=2));code=c.wait()
 d.update(exit=code,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(E/(name+'.json')).write_text(json.dumps(d,indent=2));print(name,code,flush=True)
