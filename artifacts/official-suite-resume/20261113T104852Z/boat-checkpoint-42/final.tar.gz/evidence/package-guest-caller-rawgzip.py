from pathlib import Path
import gzip,hashlib,json,datetime
R=Path('/var/lib/orb-node/work/official-suite-resume');E=R/'evidence';T=R/'transfer';rows=[]
for n in ['diagnostic-512-nanox-guest-caller']:
 for ext in ['.stdout','.stderr','.process.trace','.gdb.stdout','.gdb.stderr']:
  src=E/(n+ext);dst=T/(n+ext+'.gz');assert not dst.exists();h=hashlib.sha256();size=0
  with src.open('rb') as fi,dst.open('wb') as fo,gzip.GzipFile(filename='',mode='wb',fileobj=fo,compresslevel=9,mtime=0) as gz:
   while b:=fi.read(1024*1024):h.update(b);size+=len(b);gz.write(b)
  check=hashlib.sha256();total=0
  with gzip.open(dst,'rb') as f:
   while b:=f.read(1024*1024):check.update(b);total+=len(b)
  assert check.hexdigest()==h.hexdigest() and total==size
  data=dst.read_bytes();parts=[]
  for i,start in enumerate(range(0,len(data),524288)):
   p=T/(dst.name+f'.part{i:03d}');b=data[start:start+524288];p.write_bytes(b);parts.append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
  rows.append({'original_path':str(src),'original_bytes':size,'original_sha256':h.hexdigest(),'gzip_path':str(dst),'gzip_bytes':len(data),'gzip_sha256':hashlib.sha256(data).hexdigest(),'parts':parts,'decompression_independently_verified':True});print(src.name,size,len(data),len(parts),flush=True)
d={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compression':'lossless gzip; original and gzip SHA256 plus all512KiB parts; decompression independently verified','files':rows,'protocol_progress_path':str(E/'diagnostic512-timeout-protocol-progress.json'),'classification_path':str(E/'diagnostic512-classification-current.json'),'exit_evidence_path':str(E/'candidate512-terminal-diagnosis.json'),'guest_caller_stack':'captured exception5 from io_event pending process_interruption, then app_exit requests255; debugger later stack-read error, not native255 process-exit reproduction','no_new_runs':True};p=T/'guest-caller-rawgzip-manifest.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(d,indent=2));tmp.replace(p);print('MANIFEST',p,p.stat().st_size,flush=True)
