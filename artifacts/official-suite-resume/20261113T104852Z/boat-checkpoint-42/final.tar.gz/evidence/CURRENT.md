# Final current evidence — completed host-runtime validation

Both full official `tests/` selections completed under the documented host patches, with unchanged guest app, SDK, test assertions, screenshots, skip rules and complete `.` selection. Each collected282, slow2, timeout1800, no filters/exclusions. NanoS+ ended17:56:27Z and NanoX17:56:30Z; exact stdout, JUnit and exit receipts agree. Per-attempt frozen pytest plugin asserts imported paths, expected moduleSHA and baseline guestELF SHA inside pytest. Mainnet ran sequentially AFTER both testnet processes exited, using distinct unchanged mainnet binaries.

| Suite | Passed | Failed | Skipped | Errors | Deselected/filtered | Exit |
|---|---:|---:|---:|---:|---:|---:|
| Full testnet NanoS+ |281|0|1|0|0|0|
| Full testnet NanoX |281|0|1|0|0|0|
| Full mainnet NanoS+ |2|0|0|0|0|0|
| Full mainnet NanoX |2|0|0|0|0|0|
| Native CTest targets (30upstream+1added) |31|0|0|0|0|0|
| Bitcoin Rust app |90|0|0|0|0|0|
| Bitcoin Rust common (81unit+4integration) |85|0|0|0|0|0|
| Root common PRIVATE minimal lock overlay |66|0|0|0|0|0|

CTest is TARGET-level count only; full cmocka `native-ctest/Testing/Temporary/LastTest.log`, CMakeCache and enumeration retained. CMake native C compiler=/usr/bin/cc, SPECULOS=ON; this is distinct from LLVM21 app/FFI tooling. Passing CTest/Rust suites were not repeated. Bitcoin common integration breakdown:bip3521,bip3742,bip3751;doc0. Rootcommon overlay doc0.

## Original root lock limitation

Original root `cargo test --locked` remains exit101 due to local public manifest/lock inconsistency, not a Bitcoin behavior bug. No original tracked lock was edited. Root lock SHA256139326fa0b3bd5d75ba9447549493fd135330d1f2bf51a0d9c95ee50a04e7546. Authorized private overlay SHA256c5b183fda05b625d50581e943e52f280c9ca46ee13a590e0252c8034789785d6 adds EXACTLY cargo-vnd->existingrhai_codegen3.1 edge; no package/version/checksum changes. Its66pass is not an original-lock PASS. Actual original/newlock copies, exactdiff and commands remain included. Safe source remediation: parent reconciles that missing lock edge; no executor source/lock edit or push. Both new nested Bitcoin workspaces use their archived generated private locks with --locked.

## Fixes and baseline results

Original baseline fullretry3 both280passed1failed1upstreamskip exit1: only512 failed RemoteDisconnected/ticker, MuSig eviction passed. Authentic GDB captured guest io_event exception5 while process_interruption awaited host continuation, then app_exit requested255; observer stack-read error and teardown are separately documented. Speculos callback-retention fix alone did not resolve512. The host adapter now returns lateE000 to the existing protocol interpreter, restores caller policy/ticker, preserves review/substep cursor and retains mandatory-review guard. The first full navigationcandidate passed512 both but failed4toMaxPlus1 screenshot0 reset,280/1/1each exit1. Those completed failures remain distinct from the final fullpasses.

Newest Ragger resume checkpoint preserves unfinished click/wait/snapshot/validation indices; pendingE000 permits bounded transient loading-screen rendering before continuation, then yields before further ticks once the screen is observed. Unrelated errors propagate immediately. No golden regeneration, suppressed comparison, altered test assertion or guest/spec change. Snapshot regression before2fail/after2pass; loading before2fail2pass/after4pass; combined navigator+hostregressions46pass. Original4toMaxPlus1 finalnarrow passes both. Final complete suites above now pass both512 and4toMaxPlus1. This is host test-runtime validation, not a claim that the original baseline runtime passed.

First15:53 partial navigationattempt actually imported baselineadapter due to pytest root injection; original claim and placement correction preserved. Its exit1/JUnit/rawstdout losslessgzip remain separate from verified1421.42s narrow512pass. Archived old286501 and new2eec7d plugin bytes plus exactdiff retained; historical plugins asserted paths and recorded modulehashes only. Strong expected-SHA assertions apply only to later frozen-v2 attempts, not retroactively.

Prior full300 both279/2/1exit1, explicit exit2 interruptions, first1800 process-loss attempts counts/exitsnull, staleCore retry2 interruptions and all narrow failures remain historical raw evidence. No synthetic aggregate counts. Historical process-loss cause remains UNKNOWN: userbus/journal unavailable without rights; current cgroup counters do not prove historicOOM. No later TTL-only signals. No new full3600 runs.

## Immutable delivery and provenance

Exact current index: transfer/navigation-full-index.json. Full terminal stdout/stderr originals have losslessgzip, original/gzipSHA and parts<=524288bytes in transfer/navigation-resume-full-rawgzip-manifest.json. Separate large historical diagnostic raw addenda are indexed in large-log-archive-index.json and existing transfer manifests. Historical dated reports remain in REPORT-history-through-1800.md; their old running/expiry statements are superseded by THIS report.

Final source status/diffs, compilerversions, plugin/module/guesthash rechecks and inactive process inventory: final-navigation-provenance.json. No active owned pytest/Speculos/QEMU/Core after all completions. Confirmed parent Boat expiry18:22:27Z(epoch1794594147), advisory18:20recordonly; no test signals, no self-rent/extension. All4846tracked test/mainnet/screenshotfiles compare identical to pinned baseline. Sourcepatches exactly match finalprivate source diffs.

Vanadium045439a8c1a984b67f13b913df7c75002ef732a7; appafe126fea70c8c7d6091948bb8a8ae529ea89a60; Leanf68864d1f2af8fd9f2ca26acddb5f0abd3e80bcb; emitter8c3503fa0df74fafcd7a3b91e4319606985b7198; authentic rebuilt executableSHAe0fdcc83ac1273c077da6be968e8a4287851ba7756173e53c5a85a669c21cc98; FFIarchivee01676d36e77e8fa22368f7331f498a7af2bd7a0276b95a2968c7e66c069f889,undefined0/maxhostframe296. SDK9ea0fae9b40bb91e7c4f94bb0e9b8cf22df36306; builder98693c3b63446779677d35bd7ed7c5923949ab01; nativeCTestSpeculosad72692eacd8d961a42c95d5c4fda9d3573c2427; Raggerv1.47.4HEAD75a33226dc92d9af964c676a96bb99183bc38f5b. Never substituted LeanCandidateA092. Core32.1 authentic public release verification retained. Generateduntrackedtests/tests inventory298files retained.

Return patches for parent signing only: bitcoin-navigation-resume-with-regression.patch, ragger-navigation-resume-with-regression.patch, speculos-apdu-callback-lifetime.patch. Core fixture permanent-error patch/regression already accepted and signed by parent702ca8c; kept separate from unchanged baseline official selection. Nested-lockfiles.patch and root-common-overlay.patch included. No executor commits/sign/push/merge/deploy, credentials, stub, privileged workaround, spec/assertionweakening, helper/subagent/reviewer or other model used. Heavy builds only thisBoat,jobs<=4,Rust1.

## Sole unchanged upstream skip per testnet device

{
  "nanosp": [
    {
      "case": {
        "classname": "test_get_extended_pubkey",
        "name": "test_get_extended_pubkey_non_standard_reject_early[nanosp-nanosp]",
        "time": "0.427"
      },
      "reason": {
        "type": "pytest.skip",
        "message": "Skipped"
      },
      "text": "/var/lib/orb-node/work/official-suite-resume/app-navigation-resume/tests/instructions.py:105: Skipped"
    }
  ],
  "nanox": [
    {
      "case": {
        "classname": "test_get_extended_pubkey",
        "name": "test_get_extended_pubkey_non_standard_reject_early[nanox-nanox]",
        "time": "0.431"
      },
      "reason": {
        "type": "pytest.skip",
        "message": "Skipped"
      },
      "text": "/var/lib/orb-node/work/official-suite-resume/app-navigation-resume/tests/instructions.py:105: Skipped"
    }
  ]
}
