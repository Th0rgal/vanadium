import pathlib,subprocess,json,hashlib,datetime,os
R=pathlib.Path('/var/lib/orb-node/work/official-suite-resume');E=R/'evidence';commands=[]
def record(argv):
 p=subprocess.run(argv,cwd=R,capture_output=True,text=True);commands.append({'cwd':str(R),'argv':argv,'stdout':p.stdout,'stderr':p.stderr,'exit':p.returncode});return p
for repo in ['vanadium','app-bitcoin','app-navigation-resume','ragger-navigation-resume','speculos-callback-fix','ledger-secure-sdk','ledger-app-builder','lean-ledger-bitcoin','turbo-lean','native-ctest/_deps/speculos-src']:
 for args in [['rev-parse','HEAD'],['status','--short'],['diff','--stat']]:record(['git','-C',str(R/repo),*args])
for argv in [[str(R/'prefix/usr/bin/clang-21'),'--version'],[str(R/'prefix/usr/bin/qemu-arm-static'),'--version'],[str(R/'prefix/usr/bin/arm-none-eabi-gcc'),'--version'],[str(R/'rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustc'),'--version'],[str(R/'venv/bin/python'),'--version'],[str(R/'bitcoin-core/bitcoin-32.1/bin/bitcoind'),'--version'],['cmake','--version'],['/usr/bin/cc','--version']]:record(argv)
paths=['vanadium/Cargo.lock','vanadium/apps/bitcoin/app/Cargo.lock','vanadium/apps/bitcoin/common/Cargo.lock','turbo-lean/lean/.lake/build/bin/lean-native','speculos-candidate-runtime/speculos/api/apdu.py','speculos-candidate-runtime/speculos/mcu/seproxyhal.py','app-bitcoin/build/nanos2/bin/app.elf','app-bitcoin/build/nanox/bin/app.elf','app-mainnet/build/nanos2/bin/app.elf','app-mainnet/build/nanox/bin/app.elf','evidence/native-ctest/CMakeCache.txt','evidence/native-ctest/Testing/Temporary/LastTest.log']
files=[{'path':str(R/p),'resolved_path':str((R/p).resolve()),'bytes':(R/p).stat().st_size,'sha256':hashlib.sha256((R/p).read_bytes()).hexdigest()} for p in paths]
patches=[]
for repo,patch in [('app-navigation-resume','bitcoin-navigation-resume-with-regression.patch'),('ragger-navigation-resume','ragger-navigation-resume-with-regression.patch')]:
 actual=subprocess.check_output(['git','diff','--binary'],cwd=R/repo);saved=(E/patch).read_bytes();assert actual==saved,patch;patches.append({'path':str(E/patch),'sha256':hashlib.sha256(saved).hexdigest(),'matches_final_source_diff':True})
for dev in ['nanosp','nanox']:
 for stem in ['ragger-navigation-resume-full-'+dev,'mainnet-navigation-resume-runtime-'+dev]:
  rec=json.loads((E/(stem+'.json')).read_text());plugin=pathlib.Path(rec['frozen_plugin']['path']);assert hashlib.sha256(plugin.read_bytes()).hexdigest()==rec['frozen_plugin']['sha256']
  proof=json.loads((E/(stem+'-provenance.json')).read_text());assert proof['classification']=='IN_PYTEST_PATH_AND_EXPECTED_SHA_ASSERTED_V2'
  for module in proof['modules']:assert hashlib.sha256(pathlib.Path(module['path']).read_bytes()).hexdigest()==module['sha256']==module['actual_sha256']
  guest=proof['guest'];assert hashlib.sha256(pathlib.Path(guest['path']).read_bytes()).hexdigest()==guest['sha256']==guest['baseline_sha256']
active=[]
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  args=(p/'cmdline').read_bytes().split(b'\0');exe=args[0].decode(errors='replace')
  if str(R) in exe and (any(v==b'pytest' for v in args) or any(x in pathlib.Path(exe).name for x in ['qemu','bitcoind','speculos'])):active.append({'pid':int(p.name),'executable':exe})
 except OSError:pass
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':commands,'files':files,'patches':patches,'active_owned_test_emulation_or_core_processes':active,'all_attempt_plugin_module_guest_hashes_rechecked':True,'no_new_builds_or_test_runs':True};(E/'final-navigation-provenance.json').write_text(json.dumps(out,indent=2));print(json.dumps({'path':str(E/'final-navigation-provenance.json'),'commands':len(commands),'active':active,'patches':patches}))
