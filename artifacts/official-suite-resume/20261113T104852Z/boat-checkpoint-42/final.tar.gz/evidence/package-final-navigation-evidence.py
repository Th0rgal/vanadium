from pathlib import Path
import tarfile,json,hashlib,datetime,shutil
R=Path('/var/lib/orb-node/work/official-suite-resume');E=R/'evidence';T=R/'transfer'
# Completed large raw diagnostics have immutable lossless split addenda, indexed separately.
large={n+ext for n in ['diagnostic-512-nanox-serial-trace','diagnostic-512-nanox-candidate-trace','diagnostic-512-nanox-guest-caller','diagnostic-512-nanox-navigation-fix','diagnostic-512-nanox-navigation-fix-verified'] for ext in ['.stdout','.stderr','.process.trace']}
def keep(info):
 if any(part in ['__pycache__','.pytest_cache'] for part in Path(info.name).parts) or info.name.endswith('.pyc') or Path(info.name).name in large:return None
 return info
p=R/'.evidence-final-navigation.tar.gz'
with tarfile.open(p,'w:gz') as a:a.add(E,arcname='evidence',filter=keep)
assert p.stat().st_size<20*1024*1024
p.replace(R/'evidence.tar.gz')
archive=T/'checkpoint-navigation-final-1801.tar.gz';assert not archive.exists();shutil.copyfile(R/'evidence.tar.gz',archive);b=archive.read_bytes();parts=[]
for i,start in enumerate(range(0,len(b),524288)):
 q=T/f'checkpoint-navigation-final-1801.part{i:03d}';part=b[start:start+524288];q.write_bytes(part);parts.append({'path':str(q),'bytes':len(part),'sha256':hashlib.sha256(part).hexdigest()})
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive_path':str(archive),'whole_bytes':len(b),'whole_sha256':hashlib.sha256(b).hexdigest(),'parts':parts,'classification':'FINAL_CURRENT_FULL_TESTNET_AND_MAINNET_COMPLETE_ROOT_ORIGINAL_LOCK_LIMITATION','large_historical_raw_addenda':'See evidence/large-log-archive-index.json and prior immutable split manifests; no loss of originals','excluded':'Python/pytest bytecode/cache; binaries/buildoutputs never part of final evidence'}
p=T/'checkpoint-navigation-final-1801-manifest.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(d,indent=2));tmp.replace(p);print(json.dumps({'manifest':str(p),'whole_bytes':len(b),'whole_sha256':d['whole_sha256'],'parts':len(parts)}))
