import pathlib,json,re,datetime,collections
R=pathlib.Path('/var/lib/orb-node/work/official-suite-resume');E=R/'evidence';rows=[]
def compact(b,p):
 n=b[p];p+=1
 if n<253:return n,p
 size={253:2,254:4,255:8}[n];return int.from_bytes(b[p:p+size],'little'),p+size
for dev in ['nanosp','nanox']:
 stem='ragger-navigation-resume-full-'+dev;rec=json.loads((E/(stem+'.active.json')).read_text());row={'device':dev,'pid':rec['pid'],'completed':(E/(stem+'.json')).exists()}
 if not row['completed']:
  s=(pathlib.Path('/proc')/str(rec['pid'])/'fd/2').read_text(errors='replace');responses=re.findall(r'ragger\.apdu_logger - <= ([0-9a-f]+)',s);groups=collections.defaultdict(list);yields=0
  for h in responses:
   b=bytes.fromhex(h)
   if len(b)<3 or b[-2:]!=b'\xe0\x00':continue
   if b[0]==0x10:yields+=1
   if b[0]!=0x41 or len(b)<37:continue
   try:
    size,p=compact(b,33);index,p=compact(b,p)
    if size in [256,512]:groups[(b[1:33].hex(),size)].append(index)
   except (IndexError,KeyError):continue
  row['merkle_proof_groups']=[{'root':root,'tree_size':size,'requests':len(indices),'last_index':indices[-1],'maximum_index':max(indices),'last_indices':indices[-8:]} for (root,size),indices in groups.items()];row['yield_responses']=yields
 rows.append(row)
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'classification':'READ_ONLY_DECODED_GET_MERKLE_LEAF_PROOF_ROOT_SIZE_INDEX_AND_YIELD_NOT_TEST_PASS','scope':'Current testcase capture; distinct tree roots, no aggregation across replay','rows':rows}
with (E/'navigation-resume-phase-snapshots.jsonl').open('a') as f:f.write(json.dumps(d)+'\n')
(R/'transfer/navigation-resume-phase-latest.json').write_text(json.dumps(d,indent=2));print(json.dumps(d))
