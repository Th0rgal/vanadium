from pathlib import Path
import subprocess,json,os,datetime
R=Path('/var/lib/orb-node/work/official-suite-resume');E=R/'evidence'
for label,paths in [('before',[R/'app-bitcoin']),('after',[R/'ragger-navigation-fix/src',R/'app-navigation-fix'])]:
 env=os.environ.copy();env['PYTHONPATH']=':'.join(map(str,paths));env['PYTHONWARNINGS']='ignore::DeprecationWarning'
 n='navigation-regression-v2-'+label;a=[str(R/'venv/bin/python'),'-m','pytest','-q',str(E/'test_navigation_late_response.py'),'--junitxml='+str(E/(n+'.xml'))]
 d={'argv':a,'cwd':str(R),'env':{'PYTHONPATH':env['PYTHONPATH'],'PYTHONWARNINGS':env['PYTHONWARNINGS']},'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (E/(n+'.stdout')).open('wb') as o,(E/(n+'.stderr')).open('wb') as er:c=subprocess.run(a,cwd=R,env=env,stdout=o,stderr=er)
 d.update(exit=c.returncode,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(E/(n+'.json')).write_text(json.dumps(d,indent=2));print(n,c.returncode)
