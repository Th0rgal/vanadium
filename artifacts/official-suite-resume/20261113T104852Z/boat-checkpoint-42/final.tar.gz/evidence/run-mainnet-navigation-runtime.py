from pathlib import Path
import os,subprocess,json,datetime,hashlib
R=Path('/var/lib/orb-node/work/official-suite-resume');E=R/'evidence'
for device,build in [('nanosp','nanos2'),('nanox','nanox')]:
 name='mainnet-navigation-runtime-'+device;env=os.environ.copy();env.update(PATH=f'{R}/venv/bin:{R}/prefix/usr/bin:/usr/local/bin:/usr/bin:/bin',PYTHONPATH=':'.join(str(R/p) for p in ['evidence','ragger-navigation-fix/src','app-navigation-fix','speculos-candidate-runtime']),BITCOIN_APP_BINARY=str(R/'app-mainnet/build'/build/'bin/app.elf'),PYTHONWARNINGS='ignore::DeprecationWarning',NAV_PROVENANCE_FILE=name+'-provenance.json',TMPDIR=str(R/'tmp'))
 argv=[str(R/'venv/bin/python'),'-m','pytest','-p','navigation_candidate_provenance','.','--headless','--model',device,'--enable_slow_tests=2','--timeout=300','-ra','-v','--junitxml='+str(E/(name+'.xml'))]
 d={'cwd':str(R/'app-navigation-fix/tests_mainnet'),'argv':argv,'env':{k:env[k] for k in ['PATH','PYTHONPATH','BITCOIN_APP_BINARY','PYTHONWARNINGS','NAV_PROVENANCE_FILE','TMPDIR']},'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'confirmed_expiry_epoch':1794590547,'advisory_deadline_utc':'2026-11-13T17:20:00Z','deadline_action':'recordonly; neversignaltests','baseline_mainnet_ELF_sha256':hashlib.sha256(Path(env['BITCOIN_APP_BINARY']).read_bytes()).hexdigest(),'isolation':'sequentialmainnet default5000; simultaneousfulltestnet6401/6501 separate'}
 with (E/(name+'.stdout')).open('wb') as out,(E/(name+'.stderr')).open('wb') as err:
  c=subprocess.Popen(argv,cwd=d['cwd'],env=env,stdout=out,stderr=err);d['pid']=c.pid;(E/(name+'.active.json')).write_text(json.dumps(d,indent=2));code=c.wait()
 d.update(exit=code,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(E/(name+'.json')).write_text(json.dumps(d,indent=2));print(name,code,flush=True)
