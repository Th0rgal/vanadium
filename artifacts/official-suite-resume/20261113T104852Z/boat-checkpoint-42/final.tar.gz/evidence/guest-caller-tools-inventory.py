from pathlib import Path
import subprocess,hashlib,json,datetime,os
R=Path('/var/lib/orb-node/work/official-suite-resume');print('UTC',datetime.datetime.now(datetime.timezone.utc).isoformat());env=os.environ.copy();env['LD_LIBRARY_PATH']=str(R/'debugger/usr/lib/x86_64-linux-gnu')
commands=[[str(R/'debugger/usr/bin/gdb-multiarch'),'--data-directory='+str(R/'debugger/usr/share/gdb'),'--version'],[str(R/'prefix/usr/bin/qemu-arm-static'),'-help'],['readelf','-s',str(R/'speculos-candidate-runtime/speculos/resources/launcher')],['readelf','-s',str(R/'app-bitcoin/build/nanox/bin/app.elf')],['readelf','-S',str(R/'app-bitcoin/build/nanox/bin/app.elf')],['git','-C',str(R/'app-bitcoin'),'status','--short','--untracked-files=no'],['git','-C',str(R/'ledger-secure-sdk'),'status','--short','--untracked-files=no']]
for a in commands:
 z=subprocess.run(a,env=env,capture_output=True,text=True);print('ARGV',json.dumps(a),'EXIT',z.returncode);print(z.stdout);print(z.stderr)
for n in ['gdb-multiarch','gdb','libbabeltrace1','libipt2','libsource-highlight4t64','libsource-highlight-common','libboost-regex1.83.0','libdebuginfod1t64']:
 for p in (R/'debs').glob(n+'_*.deb'):print('OFFICIAL_DEB_SHA256',p.name,hashlib.sha256(p.read_bytes()).hexdigest())
for n in ['app-bitcoin/build/nanox/bin/app.elf','speculos-candidate-runtime/speculos/resources/launcher','prefix/usr/bin/qemu-arm-static','debugger/usr/bin/gdb-multiarch','vanadium/Cargo.lock','evidence/guest-exit-caller.gdb']:
 p=R/n;print('ARTIFACT_SHA256',n,hashlib.sha256(p.read_bytes()).hexdigest())
