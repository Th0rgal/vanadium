from pathlib import Path
R=Path('/var/lib/orb-node/work/official-suite-resume')
p=R/'ragger-navigation-fix/src/ragger/navigator/navigator.py'
s=p.read_text(); start=0
for _ in range(2):
 a=s.index('        self._backend.pause_ticker()\n',start)+len('        self._backend.pause_ticker()\n')
 b=s.index('        self._backend.resume_ticker()',a)
 body=s[a:b].strip('\n')
 s=s[:a]+'        try:\n'+''.join('    '+line+'\n' if line else '\n' for line in body.splitlines())+'        finally:\n    '+s[b:]
 start=a+len(body)+100
p.write_text(s)
p=R/'app-navigation-fix/ragger_bitcoin/ragger_bitcoin.py';s=p.read_text()
s=s.replace('from ragger.navigator import Navigator, NavInsID','from ragger.navigator import Navigator, NavInsID\nfrom ragger.backend.interface import RaisePolicy\nfrom ragger.error import ExceptionRAPDU')
s=s.replace('testname: str, index: int) -> Tuple[int, bytes, int]:\n        sub_index = 0','testname: str, index: int, sub_index: int = 0) -> Tuple[int, bytes, int, int]:')
a=s.index('        with self.transport_client.exchange_async_raw(');b=s.index('        sw, response = self.last_async_response()',a)
body=s[a:b];body=body.replace('zip(text[index],','zip(text[index][sub_index:],').replace('instruction_on_text[index],','instruction_on_text[index][sub_index:],').replace('instruction_until_text[index],','instruction_until_text[index][sub_index:],').replace('save_screenshot[index]):','save_screenshot[index][sub_index:]):').replace('                index += 1','                index += 1\n                sub_index = 0')
s=s[:a]+"        # A late protocol response must unwind navigation before its ticker loop\n        # expires the guest's interruption timeout. Restore the caller's policy.\n        policy = self.transport_client.raise_policy\n        self.transport_client.raise_policy = RaisePolicy.RAISE_ALL_BUT_0x9000\n        try:\n"+''.join('    '+line+'\n' for line in body.splitlines())+'        except ExceptionRAPDU as response:\n            if response.status != 0xE000:\n                raise\n            return response.status, response.data, index, sub_index\n        finally:\n            self.transport_client.raise_policy = policy\n'+s[b:]
s=s.replace('return sw, response, index','return sw, response, index, sub_index')
s=s.replace('        index = 0\n\n        sw, response, index = self.ragger_navigate(','        index = 0\n        sub_index = 0\n\n        sw, response, index, sub_index = self.ragger_navigate(')
s=s.replace('            sw, response, index = self.ragger_navigate(','            sw, response, index, sub_index = self.ragger_navigate(')
s=s.replace('navigator, apdu, instructions, testname, index)','navigator, apdu, instructions, testname, index, sub_index)')
p.write_text(s)
