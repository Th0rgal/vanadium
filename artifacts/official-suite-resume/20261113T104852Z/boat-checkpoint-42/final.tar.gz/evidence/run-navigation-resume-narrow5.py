import pathlib,os,json,subprocess,datetime,concurrent.futures
R=pathlib.Path('/var/lib/orb-node/work/official-suite-resume');E=R/'evidence'
def run(dev,port):
 name='navigation-resume-narrow5-'+dev;assert not (E/(name+'.active.json')).exists()
 env=os.environ.copy();env.update(PATH=f'{R}/venv/bin:{R}/prefix/usr/bin:/usr/local/bin:/usr/bin:/bin',PYTHONPATH=':'.join(str(R/p) for p in ['evidence','ragger-navigation-resume/src','app-navigation-resume','speculos-candidate-runtime']),TMPDIR=str(R/'tmp'),NAV_PROVENANCE_FILE=name+'-provenance.json',BITCOIND=str(R/'bitcoin-core/bitcoin-32.1/bin/bitcoind'))
 argv=[str(R/'venv/bin/python'),'-m','pytest','-p','navigation_resume_provenance','test_sign_psbt.py::test_sign_psbt_singlesig_wpkh_4toMaxPlus1','--device',dev,'--model',dev,'--speculos_port='+str(port),'--enable_slow_tests=2','--timeout=1800','-ra','-v','--tb=short','--junitxml='+str(E/(name+'.xml'))]
 d={'argv':argv,'cwd':str(R/'app-navigation-resume/tests'),'env':{k:env[k] for k in ['PATH','PYTHONPATH','TMPDIR','NAV_PROVENANCE_FILE','BITCOIND']},'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'confirmed_expiry_epoch':1794590547,'advisory':'17:20 recordonly; never signals','classification':'NARROW_SNAPSHOT_CURSOR_DIAGNOSTIC_NOT_FULL_SUITE'}
 with (E/(name+'.stdout')).open('wb') as out,(E/(name+'.stderr')).open('wb') as err:
  p=subprocess.Popen(argv,cwd=d['cwd'],env=env,stdout=out,stderr=err);d['pid']=p.pid;(E/(name+'.active.json')).write_text(json.dumps(d,indent=2));code=p.wait()
 d.update(exit=code,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(E/(name+'.json')).write_text(json.dumps(d,indent=2));return {dev:code}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for result in pool.map(lambda a:run(*a),[('nanosp',7401),('nanox',7501)]):print(result,flush=True)
