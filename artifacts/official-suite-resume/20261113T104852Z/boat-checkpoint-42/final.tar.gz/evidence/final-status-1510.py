import pathlib,subprocess,hashlib,json,datetime,os
R=pathlib.Path('/var/lib/orb-node/work/official-suite-resume');print('OBSERVED_UTC',datetime.datetime.now(datetime.timezone.utc).isoformat())
for name in ['vanadium','app-bitcoin','app-mainnet','lean-ledger-bitcoin','turbo-lean','ledger-secure-sdk','ledger-app-builder','native-ctest/_deps/speculos-src','speculos-callback-fix']:
 print('TREE',name)
 for a in [['git','rev-parse','HEAD'],['git','status','--short','--untracked-files=all'],['git','diff','--binary']]:
  z=subprocess.run(a,cwd=R/name,capture_output=True,text=True);print('ARGV',a,'EXIT',z.returncode);print(z.stdout);print(z.stderr)
for name in ['vanadium/Cargo.lock','vanadium/apps/bitcoin/app/Cargo.lock','vanadium/apps/bitcoin/common/Cargo.lock','turbo-lean/lean/.lake/build/bin/lean-native','lean-ledger-bitcoin/ffi/vanadium/build/host/liblean_ledger_bitcoin.a','app-bitcoin/build/nanos2/bin/app.elf','app-bitcoin/build/nanox/bin/app.elf','root-lock-overlay/Cargo.lock']:
 p=R/name
 if p.is_file():print('SHA256',hashlib.sha256(p.read_bytes()).hexdigest(),name)
assert hashlib.sha256((R/'vanadium/Cargo.lock').read_bytes()).hexdigest()=='139326fa0b3bd5d75ba9447549493fd135330d1f2bf51a0d9c95ee50a04e7546'
for argv in [['/usr/bin/cc','--version'],[str(R/'venv/bin/python'),'-m','pip','show','speculos','ragger'],['qemu-arm-static','--version']]:
 z=subprocess.run(argv,capture_output=True,text=True);print('ARGV',argv,'EXIT',z.returncode);print(z.stdout);print(z.stderr)
inv=[]
for rootname in ['app-bitcoin','app-mainnet','app-testnet','app-slow-diagnostic']:
 base=R/rootname/'tests/tests'
 if not base.exists():continue
 for p in base.rglob('*'):
  if p.is_file():inv.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(R/'evidence/generated-tests-tests-final-inventory.json').write_text(json.dumps({'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inventory_only_no_file_contents':True,'files':inv},indent=2));print('GENERATED_TESTS_TESTS_FILES',len(inv))
alive=[]
for p in pathlib.Path('/proc').glob('[0-9]*'):
 try:
  a=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode()
  if (' -m pytest ' in a or ' -m speculos ' in a or a.startswith('qemu-arm-static ')) and str(R) in a:alive.append({'pid':int(p.name),'argv':a})
 except (OSError,UnicodeError):pass
print('ACTIVE_TEST_EMULATOR_PROCESSES',json.dumps(alive))
